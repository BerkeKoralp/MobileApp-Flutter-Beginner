import 'package:get/get.dart';
import 'package:my_travely1/Planlar/Plans.dart';

class CardController extends GetxController{
  //Dictionary
  var _plans= {}.obs;

  void addPlan(Plans plan){
     if(_plans.containsKey(plan)){
       return;
     }else{
       _plans[plan]=1;
     }
  }
  get plans => _plans;

  void removePlan(Plans plan){
    if(_plans.containsKey(plan)){
      _plans.removeWhere((key, value) => key== plan);
    }
  }

}