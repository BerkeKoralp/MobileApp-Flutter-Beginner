import 'package:flutter/material.dart';
import 'package:my_travely1/card_controller.dart';
import 'main.dart';
import 'Cardx.dart';
import 'package:get/get.dart';
import 'card_controller.dart';

class MyListPage extends StatefulWidget {
   MyListPage({super.key, required this.title});

  final CardController controller = Get.put(CardController());
  final String title;

  @override
  State<MyListPage> createState() => _MyListPageState();
}
class _MyListPageState extends State<MyListPage> {

  int _selectedIndex = 0;
  static const TextStyle optionStyle =
  TextStyle(fontSize: 30, fontWeight: FontWeight.bold);
  static const List<Widget> _bottomPages = <Widget>[
    MyHomePage(title: 'Travelly Home Page'),
    ProfilePage(title: "Profile"),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    if (index == 0) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => MyHomePage(title: 'Travelly Home Page'),
        ),
      );
    } else if (index == 1) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => ProfilePage(title: "Profile"),
        ),
      );
    } else if (index == 2) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => MyListPage(title: "My List"),
        ),
      );
    }
  }
  ScrollController _scrollController = ScrollController();

  scrollToBottom() async{
    WidgetsBinding.instance!.addPostFrameCallback(
          (_) => _scrollController.jumpTo(
        _scrollController.position.maxScrollExtent,
      ),
    );
  }
final CardController controller =Get.find();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "My Plans",
          style: TextStyle(color: Colors.blueGrey),
        ),
        brightness: Brightness.dark,
        backgroundColor: Colors.yellow.shade600,
        centerTitle: true
      ),
    body: Obx(() =>
       SizedBox(
        height: 600,
        child: ListView.builder(
          itemCount: controller.plans.length,
          itemBuilder: (BuildContext context, int index){
            return Mylist_cards(
              controller: controller,
              plan: controller.plans.keys.toList()[index],
              index: index,
            );
          }

        ),
      ),
    ),
    bottomNavigationBar: BottomNavigationBar(
      items: const <BottomNavigationBarItem>[
        BottomNavigationBarItem(
          icon: Icon(Icons.home),
          label: 'Home',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.account_circle_rounded),
          label: 'Profile',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.location_on_outlined),
          label: 'My List',
        ),
      ],
      currentIndex: _selectedIndex,
      onTap: _onItemTapped,
      selectedItemColor: Colors.pink[800],
    ),    //Bottom Navigation Bar
    );
  }
}
