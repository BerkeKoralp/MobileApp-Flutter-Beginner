import 'package:flutter/material.dart';
import '../Planlar/Plans.dart';
import 'plan_catalog_restaurants_Ankara.dart';
class PlansRestaurantAnkara extends StatelessWidget {
  const PlansRestaurantAnkara({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Flexible(
      child: ListView.builder(
          itemCount: Plans.plansRestaurant_Ankara.length,
          itemBuilder: (BuildContext context,int index){
            return PlanCatalogProductAnkara(index: index);
          }),
    );

  }
}
