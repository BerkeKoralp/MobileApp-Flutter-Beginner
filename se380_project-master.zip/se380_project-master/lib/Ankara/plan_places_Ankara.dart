import 'package:flutter/material.dart';
import 'package:my_travely1/%C4%B0zmir/plan_place_catalog.dart';
import 'package:my_travely1/Ankara/plan_place_catalog_Ankara.dart';
import '../Planlar/Plans.dart';

class PlansPlacesAnkara extends StatelessWidget {
  const PlansPlacesAnkara({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Flexible(
      child: ListView.builder(
          itemCount: Plans.plansPlaces_Ankara.length,
          itemBuilder: (BuildContext context,int index){
            return PlanPlaceCatalogAnkara(index: index);
          }),
    );

  }
}
