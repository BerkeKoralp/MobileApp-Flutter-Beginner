import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:my_travely1/Planlar/Plans.dart';
import 'package:get/get.dart';
import '../card_controller.dart';

class PlanPlaceCatalogAnkara extends StatelessWidget {
  final cardController = Get.put(CardController());
  final int index;

  PlanPlaceCatalogAnkara({Key? key, required this.index}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 20.0),
      height: 200.0,
      width: 330,
      padding: const EdgeInsets.all(2.0),
      decoration:
      BoxDecoration(border: Border.all(color: Colors.black, width: 5)),
      child: ListView(
// This next line does the trick.
          scrollDirection: Axis.horizontal,
          children: <Widget>[
            Container(
              width: 140.0,
              decoration: BoxDecoration(
                image: DecorationImage(
                  fit: BoxFit.fill,
                  image: NetworkImage(Plans.plansPlaces_Ankara[index].imageUrl),
                ),
              ),
            ),
            Expanded(
              child: Container(
                  width: 140.0,
                  color: Colors.white,
                  child: Column(
                    children: [
                      Text(
                        Plans.plansPlaces_Ankara[index].title,
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        ),
                      ),
                      Text(Plans.plansPlaces_Ankara[index].description)
                    ],
                  )),
            ),
            Expanded(
              child: Container(
                width: 140.0,
                color: Colors.green,
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      Expanded(
                        flex: 2,
                        child: ElevatedButton(
//Add to PLAN list
                          onPressed: () {
                            cardController
                                .addPlan(Plans.plansPlaces_Ankara[index]);
                          },
                          child: Container(
                            margin: EdgeInsets.all(12.0),
                            padding: EdgeInsets.all(8.0),
                            child: Icon(
                              Icons.add,
                              size: 20.0,
                            ),
                            height: 50,
                            width: 50,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Color.fromRGBO(36, 113, 163, 1),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 2,
                        child: ElevatedButton(
                          onPressed: () {},
                          child: Container(
                            margin: EdgeInsets.all(12.0),
                            padding: EdgeInsets.all(8.0),
                            child: Icon(
                              Icons.favorite,
                              size: 20.0,
                            ),
                            height: 50,
                            width: 50,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Color.fromRGBO(36, 113, 163, 1),
                            ),
                          ),
                        ),
                      ),
                    ]),
              ),
            ),
//2.Row
          ]),
    );
  }
}