class Plans{
  final String description;
  final String imageUrl;
  final String title;

const  Plans({
  required this.title,
  required this.description,
  required this.imageUrl
}
   );


static const List<Plans> plansRestaurant=[
  Plans(title: "Has Kebap ",description: "Has Kebap", imageUrl: "https://images.unsplash.com/photo-1467003909585-2f8a72700288?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NXx8cmVzdGF1cmFudCUyMGZvb2R8ZW58MHx8MHx8&auto=format&fit=crop&w=400&q=60"),
  Plans(title: "Boğaziçi Balık ",description: "Balığın adresi",imageUrl: "https://images.unsplash.com/photo-1600891964599-f61ba0e24092?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8cmVzdGF1cmFudCUyMGZvb2R8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60"),
  Plans(title: "Nusret ",description: "Et ve et", imageUrl: "https://images.unsplash.com/photo-1600891964092-4316c288032e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8c3RlYWt8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60"),
  Plans(title: "Pablo Artisan ",description: "Coffe Center", imageUrl: "https://images.unsplash.com/photo-1511920170033-f8396924c348?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTF8fGNvZmZlfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60"),

];
  static const List<Plans> plansPlaces=[
    Plans(title: "İzmir Historical Elevator Building ",description: "Tarihi saat kulesi", imageUrl: "https://encrypted-tbn2.gstatic.com/licensed-image?q=tbn:ANd9GcSfM82blVFi3s1EM1jRCrZHFRG67nvqraQkCz6Ie-nFciU253A8BXIi_ifQgGOZFZ1Jr3dFJ9z9R6Ra9-zVD9pnSw"),
    Plans(title: "Kızlarağası Inn ",description: "Kızlarağası ini",imageUrl: "https://encrypted-tbn0.gstatic.com/licensed-image?q=tbn:ANd9GcS4gNkO-K9w3eoAY4yzFuNET3uLNBkWyQWH0aeu1LG4Hixi08mBN5tfJPyjhF9OoZj13CA4BnTeX12BwOJPcwsUiA"),
    Plans(title: "Kültürpark İzmir ",description: "Park ", imageUrl: "https://encrypted-tbn1.gstatic.com/licensed-image?q=tbn:ANd9GcRTzFla8OawgJe0PbnlPe0VLbxY8buAvUYdF8Zggkijyu8iTCznyRanDZhQTJn7JebiIYjb6B3YTR-sVWBetRXrsg"),
    Plans(title: "İzmir Clock Tower ",description: "Saat kulesi", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR_05ZlHkPURTsXP0nf90Sw-PWlRTTfsyjvxxlSw84Y0WSvLCpRe1Demr6eR6QBcOpNpTBbFTGDBu-Z5pc4pLUM2g"),

  ];
  static const List<Plans> plansRestaurant_Ankara=[
    Plans(title: "Meşhur Tavacı Recep Usta ",description: "Meşhur Tavacı Recep Usta", imageUrl: "https://images.unsplash.com/photo-1467003909585-2f8a72700288?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NXx8cmVzdGF1cmFudCUyMGZvb2R8ZW58MHx8MHx8&auto=format&fit=crop&w=400&q=60"),
    Plans(title: "Meşhur Özçelik Aspava ",description: "Balığın adresi",imageUrl: "https://images.unsplash.com/photo-1600891964599-f61ba0e24092?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8cmVzdGF1cmFudCUyMGZvb2R8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60"),
    Plans(title: "Trilye Restaurant ",description: "Et ve et", imageUrl: "https://images.unsplash.com/photo-1600891964092-4316c288032e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8c3RlYWt8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60"),
    Plans(title: "Louise Cafe Brasserie & Loft ",description: "Coffe Center", imageUrl: "https://images.unsplash.com/photo-1511920170033-f8396924c348?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTF8fGNvZmZlfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60"),

  ];
  static const List<Plans> plansPlaces_Ankara=[
    Plans(title: "Ankara Castle ",description: "Tarihi saat kulesi", imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/Ankara_Castle.jpg/270px-Ankara_Castle.jpg"),
    Plans(title: "Anıtkabir ",description: "Kızlarağası ini",imageUrl: "https://encrypted-tbn0.gstatic.com/licensed-image?q=tbn:ANd9GcS4gNkO-K9w3eoAY4yzFuNET3uLNBkWyQWH0aeu1LG4Hixi08mBN5tfJPyjhF9OoZj13CA4BnTeX12BwOJPcwsUiA"),
    Plans(title: "Ulucanlar Prison Museum",description: "Park ", imageUrl: "https://encrypted-tbn1.gstatic.com/licensed-image?q=tbn:ANd9GcRTzFla8OawgJe0PbnlPe0VLbxY8buAvUYdF8Zggkijyu8iTCznyRanDZhQTJn7JebiIYjb6B3YTR-sVWBetRXrsg"),
    Plans(title: "Kuğulu Park ",description: "Saat kulesi", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR_05ZlHkPURTsXP0nf90Sw-PWlRTTfsyjvxxlSw84Y0WSvLCpRe1Demr6eR6QBcOpNpTBbFTGDBu-Z5pc4pLUM2g"),

  ];
  static const List<Plans> plansRestaurant_Istanbul=[
    Plans(title: "A ",description: "Meşhur Tavacı Recep Usta", imageUrl: "https://images.unsplash.com/photo-1467003909585-2f8a72700288?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NXx8cmVzdGF1cmFudCUyMGZvb2R8ZW58MHx8MHx8&auto=format&fit=crop&w=400&q=60"),
    Plans(title: "Meşhur Özçelik Aspava ",description: "Balığın adresi",imageUrl: "https://images.unsplash.com/photo-1600891964599-f61ba0e24092?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8cmVzdGF1cmFudCUyMGZvb2R8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60"),
    Plans(title: "Trilye Restaurant ",description: "Et ve et", imageUrl: "https://images.unsplash.com/photo-1600891964092-4316c288032e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8c3RlYWt8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60"),
    Plans(title: "Louise Cafe Brasserie & Loft ",description: "Coffe Center", imageUrl: "https://images.unsplash.com/photo-1511920170033-f8396924c348?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTF8fGNvZmZlfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60"),

  ];
  static const List<Plans> plansPlaces_Istanbul=[
    Plans(title: "B ",description: "Tarihi saat kulesi", imageUrl: "https://encrypted-tbn2.gstatic.com/licensed-image?q=tbn:ANd9GcSfM82blVFi3s1EM1jRCrZHFRG67nvqraQkCz6Ie-nFciU253A8BXIi_ifQgGOZFZ1Jr3dFJ9z9R6Ra9-zVD9pnSw"),
    Plans(title: "Anıtkabir ",description: "Kızlarağası ini",imageUrl: "https://encrypted-tbn0.gstatic.com/licensed-image?q=tbn:ANd9GcS4gNkO-K9w3eoAY4yzFuNET3uLNBkWyQWH0aeu1LG4Hixi08mBN5tfJPyjhF9OoZj13CA4BnTeX12BwOJPcwsUiA"),
    Plans(title: "Ulucanlar Prison Museum",description: "Park ", imageUrl: "https://encrypted-tbn1.gstatic.com/licensed-image?q=tbn:ANd9GcRTzFla8OawgJe0PbnlPe0VLbxY8buAvUYdF8Zggkijyu8iTCznyRanDZhQTJn7JebiIYjb6B3YTR-sVWBetRXrsg"),
    Plans(title: "Kuğulu Park ",description: "Saat kulesi", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR_05ZlHkPURTsXP0nf90Sw-PWlRTTfsyjvxxlSw84Y0WSvLCpRe1Demr6eR6QBcOpNpTBbFTGDBu-Z5pc4pLUM2g"),

  ];
}