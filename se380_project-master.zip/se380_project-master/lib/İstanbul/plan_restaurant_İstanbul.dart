import 'package:flutter/material.dart';
import 'package:my_travely1/%C4%B0stanbul/Plan_catalog_restaurants_%C4%B0stanbul.dart';
import '../Planlar/Plans.dart';
class PlansRestaurantIstanbul extends StatelessWidget {
  const PlansRestaurantIstanbul({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Flexible(
      child: ListView.builder(
          itemCount: Plans.plansRestaurant_Istanbul.length,
          itemBuilder: (BuildContext context,int index){
            return PlanCatalogProductIstanbul(index: index);
          }),
    );

  }
}
