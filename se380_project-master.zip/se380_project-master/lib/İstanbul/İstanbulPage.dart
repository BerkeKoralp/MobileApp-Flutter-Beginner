import 'dart:ui';
import 'package:my_travely1/%C4%B0stanbul/plan_places_%C4%B0stanbul.dart';
import 'package:my_travely1/%C4%B0stanbul/plan_restaurant_%C4%B0stanbul.dart';
import 'package:my_travely1/%C4%B0zmir/PlansPlaces.dart';
import 'package:my_travely1/Ankara/plan_places_Ankara.dart';
import 'package:my_travely1/Ankara/plans_restaurant_Ankara.dart';

import '../main.dart';
import 'package:flutter/material.dart';
import 'package:my_travely1/Planlar/Mylist_cards.dart';
import '../Planlar/my_list_page.dart';
import 'package:get/get.dart';
import '../Planlar/Plans.dart';
import '../İzmir/plan_catalog_product.dart';
import '../İzmir/plans_restaurants_Izmir.dart';

import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

class IstanbulPage extends StatefulWidget {
  const IstanbulPage({
    Key? key,
  }) : super(key: key);


  @override
  State<IstanbulPage> createState() => _IstanbulPageState();
}
class _IstanbulPageState extends State<IstanbulPage> {
  int _selectedIndex = 0;
  static const TextStyle optionStyle =
  TextStyle(fontSize: 30, fontWeight: FontWeight.bold);
  static  List<Widget> _bottomPages = <Widget>[
    MyHomePage(title: 'Travelly Home Page'),
    ProfilePage(title: "Profile"),
    MyListPage(title: "My List"),
  ];
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    if (index == 0) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => MyHomePage(title: 'Travelly Home Page'),
        ),
      );
    } else if (index == 1) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => ProfilePage(title: "Profile"),
        ),
      );
    } else if (index == 2) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => MyListPage(title: "My List"),
        ),
      );
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("İstanbul Page is Here"),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          Background(),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Center(
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: SizedBox(
                    height: 40,
                    width: 200,
                    child: ElevatedButton(
                        onPressed: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (context) => FoodPage(),
                            ),
                          );
                        },
                        child: Text('Food Page')),
                  ),
                ),
              ),
              Center(
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: SizedBox(
                    height: 40,
                    width: 200,
                    child: ElevatedButton(
                        onPressed: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (context) => PlacesPage(),
                            ),
                          );
                        },
                        child: Text('Places Page')),
                  ),
                ),
              ),
              Center(
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: SizedBox(
                    height: 40,
                    width: 200,
                    child: ElevatedButton(
                        onPressed: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (context) => TransportationPage(),
                            ),
                          );
                        },
                        child: Text('Transportation Page')),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.account_circle_rounded),
            label: 'Profile',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.location_on_outlined),
            label: 'My List',
          ),
        ],
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        selectedItemColor: Colors.pink[800],
      ),
    );
  }
}

class TransportationPage extends StatefulWidget {
  const TransportationPage({Key? key}) : super(key: key);

  @override
  State<TransportationPage> createState() => _TransportationPageState();
}

class _TransportationPageState extends State<TransportationPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Transportation Page'),
      ),
      body: Column(
        //mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[

          Padding(
            padding: const EdgeInsets.all(8.0),
            child: DecoratedBox(
              decoration: ShapeDecoration(
                  color: Colors.blueGrey,
                  shape: Border.all(color: Colors.blueGrey, width: 2.5)),
              child: Column(children: <Widget>[
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    'Available Transportation Options For İstanbul',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 25,
                      //fontFamily: 'Josephin Sans'
                    ),
                  ),
                ),
              ]),
            ),
          ),
          Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: SizedBox(
                  height: 60,
                  width: 150,
                  child: ElevatedButton.icon(
                    onPressed: () async {
                      const url = 'https://adnanmenderesairport.com/tr-TR/yolcu-ve-ziyaretci-rehberi/ulasim';
                      if (await canLaunch(url)) {
                        await launch(url);
                      } else {
                        throw 'Could not launch $url';
                      }
                    },
                    icon: Icon(
                        Icons.airplane_ticket_outlined,
                        size: 60),
                    label: Text('Airport'),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: SizedBox(
                  height: 60,
                  width: 150,
                  child: ElevatedButton.icon(
                      onPressed: ()
                      {
                        showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return AlertDialog(
                              title: Text('Taxi'),
                              content: Text('Taxi is a transportation opportunity for this city. You can try to find the closest taxi station via Google.'),
                              actions: [
                                TextButton(
                                  child: Text('OK'),
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                  },
                                ),
                              ],
                            );
                          },
                        );
                      },

                      icon: Icon(
                        Icons.local_taxi_outlined,
                        size: 60,),
                      label: Text('Taxi')
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: SizedBox(
                  height: 60,
                  width: 150,
                  child: ElevatedButton.icon(
                    onPressed: ()async {
                      const url = 'https://www.izmirmetro.com.tr/';
                      if (await canLaunch(url)) {
                        await launch(url);
                      } else {
                        throw 'Could not launch $url';
                      }
                    },
                    icon: Icon(
                      Icons.subway_outlined,
                      size: 60,
                    ),
                    label: Text('Subway'),
                  ),
                ),
              ),

              Padding(
                padding: const EdgeInsets.all(8.0),
                child: SizedBox(
                  height: 60,
                  width: 150,
                  child: ElevatedButton.icon(
                      onPressed: ()async {
                        const url = 'https://www.tramizmir.com';
                        if (await canLaunch(url)) {
                          await launch(url);
                        } else {
                          throw 'Could not launch $url';
                        }
                      },
                      icon: Icon(
                        Icons.tram_outlined,
                        size: 60,
                      ),
                      label: Text('Tram')
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: SizedBox(
                  height: 60,
                  width: 150,
                  child: ElevatedButton.icon(
                      onPressed: ()async {
                        const url = 'https://www.izdeniz.com.tr';
                        if (await canLaunch(url)) {
                          await launch(url);
                        } else {
                          throw 'Could not launch $url';
                        }
                      },
                      icon: Icon(
                        Icons.directions_ferry_outlined,
                        size: 60,
                      ),
                      label: Text('Ferry')
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: SizedBox(
                  height: 60,
                  width: 150,
                  child: ElevatedButton.icon(
                    onPressed: ()async {
                      const url = 'https://www.eshot.gov.tr/tr/Anasayfa';
                      if (await canLaunch(url)) {
                        await launch(url);
                      } else {
                        throw 'Could not launch $url';
                      }
                    },
                    icon: Icon(
                      Icons.directions_bus_filled_outlined,
                      size: 60,
                    ),
                    label: Text('Bus'),
                  ),
                ),
              ),
            ],
          )
        ],
      ),
    );
  }
}

class PlacesPage extends StatefulWidget {
  const PlacesPage({Key? key}) : super(key: key);

  @override
  State<PlacesPage> createState() => _PlacesPageState();
}

class _PlacesPageState extends State<PlacesPage> {
  int _selectedIndex = 0;
  static const TextStyle optionStyle =
  TextStyle(fontSize: 30, fontWeight: FontWeight.bold);
  static  List<Widget> _bottomPages = <Widget>[
    MyHomePage(title: 'Travelly Home Page'),
    ProfilePage(title: "Profile"),
    MyListPage(title: "My List"),
  ];
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    if (index == 0) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => MyHomePage(title: 'Travelly Home Page'),
        ),
      );
    } else if (index == 1) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => ProfilePage(title: "Profile"),
        ),
      );
    } else if (index == 2) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => MyListPage(title: "My List"),
        ),
      );

    }
  }
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Places Page"),
      ),
      body: Column(
          children:[PlansPlacesIstanbul()]
      )
      ,
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.account_circle_rounded),
            label: 'Profile',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.location_on_outlined),
            label: 'My List',
          ),
        ],
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        selectedItemColor: Colors.pink[800],
      ),
    );
  }
}


class FoodPage extends StatefulWidget {
  const FoodPage({Key? key}) : super(key: key);

  @override
  State<FoodPage> createState() => _FoodPageState();
}

class _FoodPageState extends State<FoodPage> {
  int _selectedIndex = 0;
  static const TextStyle optionStyle =
  TextStyle(fontSize: 30, fontWeight: FontWeight.bold);
  static  List<Widget> _bottomPages = <Widget>[
    MyHomePage(title: 'Travelly Home Page'),
    ProfilePage(title: "Profile"),
    MyListPage(title: "My List"),
  ];
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    if (index == 0) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => MyHomePage(title: 'Travelly Home Page'),
        ),
      );
    } else if (index == 1) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => ProfilePage(title: "Profile"),
        ),
      );
    } else if (index == 2) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => MyListPage(title: "My List"),
        ),
      );
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Food Page"),
      ),
      body: Column(
          children:[PlansRestaurantIstanbul()]
      )
      ,
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.account_circle_rounded),
            label: 'Profile',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.location_on_outlined),
            label: 'My List',
          ),
        ],
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        selectedItemColor: Colors.pink[800],
      ),
    );
  }
}

class Background extends StatelessWidget {
  const Background({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints.expand(),
      decoration: const BoxDecoration(
        image: DecorationImage(
            image: AssetImage("images/izmir.jpeg"), fit: BoxFit.cover),
      ),
      child: ClipRRect(
        // make sure we apply clip it properly
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 6, sigmaY: 6),
          child: Container(
            alignment: Alignment.center,
            color: Colors.grey.withOpacity(0.1),
          ),
        ),
      ),
    );
  }
}
