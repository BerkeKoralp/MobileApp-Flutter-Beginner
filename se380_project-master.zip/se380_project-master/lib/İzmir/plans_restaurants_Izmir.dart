import 'package:flutter/material.dart';
import '../Planlar/Plans.dart';
import 'plan_catalog_product.dart';
class PlansRestaurant extends StatelessWidget {
  const PlansRestaurant({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
return Flexible(
  child: ListView.builder(
      itemCount: Plans.plansRestaurant.length,
      itemBuilder: (BuildContext context,int index){
        return PlanCatalogProduct(index: index);
      }),
);

  }
}
