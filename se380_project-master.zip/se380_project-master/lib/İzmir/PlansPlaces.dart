import 'package:flutter/material.dart';
import 'package:my_travely1/%C4%B0zmir/plan_place_catalog.dart';
import '../Planlar/Plans.dart';
import 'plan_catalog_product.dart';
class PlansPlaces extends StatelessWidget {
  const PlansPlaces({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Flexible(
      child: ListView.builder(
          itemCount: Plans.plansPlaces.length,
          itemBuilder: (BuildContext context,int index){
            return PlanPlaceCatalog(index: index);
          }),
    );

  }
}
