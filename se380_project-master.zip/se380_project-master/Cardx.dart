import 'dart:ui';
import 'package:flutter/material.dart';

class Cardx extends StatefulWidget {
  String? description;
  String? photo_url;

  Cardx(String descriptionOfCard,String photoUrl)
  {
    this.description=descriptionOfCard;
    this.photo_url=photoUrl;
  }


  @override
  State<Cardx> createState() => _CardxState();
}

class _CardxState extends State<Cardx> {
  get description => widget.description;
get photo_url=> widget.photo_url;




  @override
  Widget build(BuildContext context) {
 return   Container(
   margin: const EdgeInsets.symmetric(vertical: 20.0),
   height: 200.0,
   width: 330,
   padding: const EdgeInsets.all(2.0),
   decoration:
   BoxDecoration(border: Border.all(color: Colors.black, width: 5)),
   child: ListView(
     // This next line does the trick.
       scrollDirection: Axis.horizontal,
       children: <Widget>[
         Container(
           width: 140.0,
           decoration: BoxDecoration(
             image: DecorationImage(
               fit: BoxFit.fill,
               image: NetworkImage(photo_url!),
             ),
           ),
         ),
         Container(
           width: 140.0,
           color: Colors.white,
           child: Text(description!),
         ),
         Container(
           width: 140.0,
           color: Colors.green,
           child: ElevatedButton(
             onPressed: () {

             },
             child:
             Padding(
               padding: const EdgeInsets.all(8.0),
               child: Container(
                 child: Icon(
                   Icons.add,
                   size: 20.0,
                 ),
                 height: 50,
                  width: 50,
                 decoration: BoxDecoration(
                   shape: BoxShape.circle,
                   color: Color.fromRGBO(36, 113,163, 1),
                 ),
               ),
             ),
           ),
         ),
       
       ]),
 );
  }
}
